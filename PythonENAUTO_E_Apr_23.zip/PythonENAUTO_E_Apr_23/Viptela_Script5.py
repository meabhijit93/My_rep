import os
import yaml
import json
from pprint import pprint
from pprint import PrettyPrinter
import netaddr
import jinja2
import requests
import datetime
import urllib3
from vmanage.api.authentication import Authentication
from vmanage.api.device_templates import DeviceTemplates
from vmanage.data.template_data import TemplateData

def read_yaml(path=''):
    with open(path) as file:
        yaml_content = yaml.safe_load(file.read())
    return yaml_content

urllib3.disable_warnings()
StartTime = datetime.datetime.now(datetime.timezone.utc)
later = StartTime
EndTime = later + datetime.timedelta(seconds=2)

Current_Directory = os.path.dirname(os.path.realpath(__file__)) #.encode('unicode-escape') #.decode()

username = 'admin'
password = 'Elastic+123'
vmanage_host = '172.16.4.41'

def check_directory_exists(vedgeName):
    PATH = Current_Directory + f'\\FINAL_CONFIG_FILES\\{vedgeName}'
    isdir = os.path.isdir(PATH)
    if isdir == True:
        pass
    else:
        os.mkdir(PATH)

def open_template_write_config_file(template_file, yaml_data):
    with open(template_file) as f:
        ce_template = f.read()
    template = jinja2.Template(ce_template)
    ce_config = template.render(yaml_data)
    return ce_config

def create_config_in_folder(vEdge_name, modified_yaml_data, Template_File1):
    check_directory_exists(vEdge_name)
    filename2 = Current_Directory + f'\\FINAL_CONFIG_FILES\\{vEdge_name}\\{vEdge_name} CONFIG.txt'
    vedge_config = open_template_write_config_file(Template_File1, modified_yaml_data)
    with open(filename2, 'w') as f:
        f.write(vedge_config)

def ask_to_push(vedgeName, dev):
    template_name = f'{dev["location"].upper()}_{vedgeName.upper()}_{dev["vEdge_Role"].upper()}_{dev["topology"].upper()}_CLI'
    comment1 = '\n---> TEMPLATE WITH THE NAME: '
    print(comment1)
    print(template_name, '<---')

def push_to_vmanage(vedgeName, dev):
    PATH = Current_Directory + f'\\FINAL_CONFIG_FILES\\{vedgeName}\\{vedgeName} CONFIG.txt'
    with open(PATH, 'r') as f:
        file_contents = f.read()
    
    template_name = f'{dev["location"].upper()}_{vedgeName.upper()}_{dev["vEdge_Role"].upper()}_{dev["topology"].upper()}_CLI'
    template_desc = f'{dev["ACME_site_code"].upper()}_{dev["vEdge_Role"].upper()}_{dev["topology"].upper()}_TEMPLATE_V{dev["template_ver"]}'
    device_type = dev['vEdge_Model']
    template_dict = {
        "deviceType": device_type,
        "templateConfiguration": file_contents,
        "configType": "file",
        "feature": "vmanage-default",
        "createdBy": username,
        "templateName": template_name,
        "templateDescription": template_desc,
        "templateAttached": 0,
        "factoryDefault": False,
    }

    pp = PrettyPrinter(indent=2)
    auth = Authentication(host=vmanage_host, user=username, password=password).login()
    device_templates = DeviceTemplates(auth, vmanage_host)

    device_template_response = device_templates.add_device_template(template_dict)

    pp.pprint(device_template_response)

def get_template_and_variable_file(Stype_no):
    Variable_File = Current_Directory + f'\\TYPE_{Stype_no}_VARIABLES.yml'
    Template_File1 = Current_Directory + f'\\TYPE_{Stype_no}_CONF.j2'
    return Variable_File, Template_File1

def main():
    Stype_no = int(input('\nEnter Site Type to Proceed[1, 2, 3, 4]: \n'))
    Variable_File, Template_File1 = get_template_and_variable_file(Stype_no)

    yaml_data = read_yaml(path=Variable_File)
    vEdge_name = yaml_data['vEdge1_name']
    create_config_in_folder(vEdge_name, yaml_data, Template_File1)

    print('\n\n' + '#'*90 + '\n' + 'CONFIGS FOR ALL vEDGE[S] CREATED SUCCESSFULLY' + '\n' + '#'*90 + '\n')
    stop_script_msg = 'HIT <ENTER> TO CONTINUE, <CNTRL + C> TO STOP SCRIPT'
    confirm = '\n\n' + '#'*90 + '\n' + 'Are you ready to Create CLI Template on VMANAGE ??' + '\n' + '#'*90 + '\n' + stop_script_msg + '\n' + ': '
    comment2 = 'WILL BE PUSHED TO VMANAGE. ARE YOU OK ?? [y/n]: '
    comment3 = f"""    >>>> Check if template already exists on vMANAGE OR
    >>>> Check vEDGE MODEL in 'TYPE_{Stype_no}_VARIABLES.yml' file. It should be same as seen in <PRE LOGS>."""

    input(confirm)
    try:
        ask_to_push(vEdge_name, yaml_data)
        template_push = input(comment2)
        if template_push != 'n':
            push_to_vmanage(vEdge_name, yaml_data)
        else:
            pass
    except Exception:
        print(f'Exception Occurred while uploading template for {vEdge_name}.')
        print(comment3)
        pass


if __name__ == "__main__":
    main()