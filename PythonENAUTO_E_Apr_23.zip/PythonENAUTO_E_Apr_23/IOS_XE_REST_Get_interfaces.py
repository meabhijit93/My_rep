import requests
import json

import urllib3

urllib3.disable_warnings()

host = '192.168.25.23'

url = f"https://{host}:443/restconf/data/ietf-interfaces:interfaces-state/interface"

payload={}
headers = {
  'Accept': 'application/yang-data+json',
  'Content-Type': 'application/yang-data+json',
  'Authorization': 'Basic YW1pdDpjaXNjbw=='
}

# response = requests.request("GET", url, headers=headers, data=payload, verify=False)
response = requests.get(url, headers=headers, data=payload, verify=False)
print(response.text)

responseDict = json.loads(response.text)

print(responseDict)
print(type(responseDict))