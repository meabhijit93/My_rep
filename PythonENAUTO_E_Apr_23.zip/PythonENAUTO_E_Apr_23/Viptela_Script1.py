# Simple Script to login to vManage

import requests
import urllib3
urllib3.disable_warnings()



BASE_URL = "https://172.16.4.41:443/"

def viptela_authenticate(BASE_URL, username, password):
    auth_url = f'{BASE_URL}j_security_check'
    payload = {'j_username' : username, 'j_password' : password}
    # headers = {
    #   'Content-Type': 'application/x-www-form-urlencoded',
    # }

    response = requests.post(auth_url, data=payload, verify=False)
    cookies = response.headers["set-cookie"]
    jsessionid = cookies.split(";")
    cookie = jsessionid[0]
    # print(cookie)

    if response.status_code == 200:
        return 'AUTH_DONE', cookie
    else:
        return 'AUTH_ERROR', response.status_code

def viptela_get_token(BASE_URL, cookies):
    token_url = f'{BASE_URL}dataservice/client/token'
    payload={}
    headers = {'Cookie': cookies}
    response = requests.get(token_url, headers=headers, data=payload, verify=False)
    if response.status_code == 200:
        return str(response.text)
    else:
        return 'TOKEN_RETRIEVAL_FAILURE'


def main():
    username = 'admin'
    password = 'Elastic+123'
    

    # CODE PORTION TO AUTHENTICATE WITH VMANAGE
    print('[AUTHENTICATING] This might take a moment...')
    auth_status, cookie_or_code = viptela_authenticate(BASE_URL, username, password)
    if 'DONE' in auth_status:
        print(f'[AUTHENTICATION STATUS] SUCCESS {auth_status.lower()} {cookie_or_code}')
    else:
        print(f'[AUTHENTICATION STATUS] FAILURE {auth_status} {cookie_or_code}')
    


    # CODE PORTION TO RETRIEVE TOKEN USED IN SUBSEQUENT REQUESTS
    print('[TOKEN RETRIEVAL] This might take a moment...')
    token = viptela_get_token(BASE_URL, cookie_or_code)
    print(f'[TOKEN RETRIEVAL] TOKEN: {token}')


if __name__ == '__main__':
    main()