import telnetlib
import getpass
import re
from TelnetlibScript5 import get_auth_data, get_ipAddresses, autheticate_my_session, \
                             write_commands_to_session, write_output_to_file

def main():
    username, password = get_auth_data()
    ipAddresses = get_ipAddresses('switchIPFile.txt')

    for ip in ipAddresses:
        session = telnetlib.Telnet(ip)
        authed_session = autheticate_my_session(session, username, password)

        commands = ['conf ter']
        for n in range(2, 21):
            commands.append(f'vlan {n}')
            commands.append(f'name P_VLAN_{n}')
        commands.append('end')

        output = write_commands_to_session(session=authed_session, 
                                           commands=commands)
        output = re.sub(r'\r\n', r'\n', output)
        write_output_to_file(filename=f'SwVLAN_{ip}.txt', filecontents=output)
        print(output)


if __name__ == '__main__':
    main()