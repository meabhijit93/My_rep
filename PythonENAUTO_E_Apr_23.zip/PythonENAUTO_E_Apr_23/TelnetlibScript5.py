import telnetlib
from getpass import getpass
import re

def get_auth_data():
    user = input('Enter your Telnet Username: ')
    password = getpass()
    return user, password

def get_ipAddresses(filename):
    with open(filename, 'r') as f:
        ipAddrList = f.read().splitlines()
    return ipAddrList

def autheticate_my_session(session, user, password):
    session.read_until(b'Username: ')
    session.write(user.encode('ascii') + b'\n')
    session.read_until(b'Password: ')
    session.write(password.encode('utf-8') + b'\n')
    return session

def write_commands_to_session(commands=['exit'], session=None):
    if session == None:
        raise ValueError('An active session object needs to be passed in as argument')
    elif type(commands) == str:
        session.write(commands.encode() + b'\n')
        session.write(b'exit\n')
    elif type(commands) == list:
        for cmd in commands:
            session.write(cmd.encode() + b'\n')
        session.write(b'exit\n')
    else:
        raise ValueError('Check your HOST availability, credentials, commands etc.')
    output = session.read_all().decode()
    return output

def write_output_to_file(filename=None, filecontents=None):
    with open(filename, 'w') as f:
        f.write(filecontents)
        f.write('\n')

def main():
    username, password = get_auth_data()
    ipAddresses = get_ipAddresses('switchIPFile.txt')

    for ip in ipAddresses:
        session = telnetlib.Telnet(ip)
        authed_session = autheticate_my_session(session, username, password)

        output = write_commands_to_session(session=authed_session, 
                                           commands=['ter len 0', 
                                                     'show run'])
        output = re.sub(r'\r\n', r'\n', output)
        write_output_to_file(filename=f'Switch_{ip}.txt', filecontents=output)
        print(output)

if __name__ == '__main__':
    main()