# Basic telnetlib script to execute few config commands on a router.
# Let's plan and write the script.

# Step 1: Import the required libraries.
import telnetlib
from getpass import getpass

# Step 2: Get user/pwd info from the user.
#         Also define the HOST(IP) with which telnet session has to be created.
user = input('Enter your Telnet Username: ')
password = getpass()

HOST = '192.168.25.21'


# Step 3: Telnet into host using this info
#         Basically we need to create a telnet session object that can used later
#         to write commands into and read outputs from.

session = telnetlib.Telnet(HOST)

# Step 4: Handle the username/password(AUTHENTICATION) prompt that the device gives.
session.read_until(b'Username: ')
session.write(user.encode('ascii') + b'\n')
session.read_until(b'Password: ')
session.write(password.encode('utf-8') + b'\n')


# Step 5: Write commands on the device.
#         We have to enter the config mode on the device and create 
#         2 new loopback interfaces.

# If you enter 'EXEC' mode then use these lines to go to Privilege Mode
# session.write(b'enable\n')
# session.write(b'cisco\n')

session.write(b'conf ter\n')
session.write(b'int loop 11\n')
session.write(b'ip address 11.11.11.11 255.255.255.255\n')
session.write(b'int loop 12\n')
session.write(b'ip address 12.12.12.12 255.255.255.255\n')
session.write(b'end\n')
session.write(b'exit\n')

# Step 6: Print out what we have done on the device.
#         First we need to decode the buffer and then print it.

print(session.read_all().decode())