from ncclient import manager
import xmltodict

conn_params = {
    'host': "192.168.25.23",
    'port': "830",
    'username': "python",
    'password': "python",
    'hostkey_verify': False,
}

netconf_template = open('config-native-vrf-template.xml').read()

with manager.connect(**conn_params) as m:
    netconf_payload = netconf_template.format(
            vrf_name="MY-TEST-VRF2",
            vrf_desc="Configured by NETCONF by Amit",
            export_rt='200:1',
            import_rt='200:1',
            vrf_rd='200:1'
        )

    print(netconf_payload)

    netconf_reply = m.edit_config(netconf_payload, target='running')
    print(netconf_reply)