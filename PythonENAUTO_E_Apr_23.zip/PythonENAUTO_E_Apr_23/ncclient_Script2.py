from ncclient import manager
import xmltodict


host = '192.168.25.23'
port = '830'
username = 'python'
password = 'python'

netconf_filter = open('filter-ietf-interfaces.xml').read()

with manager.connect(host=host, port=port, username=username, password=password, hostkey_verify=False) as m:
    netconf_reply = m.get(netconf_filter)

    interface_dict = xmltodict.parse(netconf_reply.xml)
    intf_data = interface_dict['rpc-reply']['data']
    intf_config = intf_data['interfaces']['interface']
    intf_oper = intf_data['interfaces-state']['interface']

    print('\n')
    print('Interfaces details are as follows: ')
    print('Name: {a}'.format(a=intf_config['name']['#text']))
    print('Description: {}'.format(intf_config['description']))
    print('Type: {}'.format(intf_config['type']['#text']))
    print('MAC Address: {}'.format(intf_oper['phys-address']))
    print('Packets Input: {}'.format(intf_oper['statistics']['in-unicast-pkts']))
    print('Packets Output: {}'.format(intf_oper['statistics']['out-unicast-pkts']))


