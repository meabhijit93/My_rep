# Using Netmiko to take command outputs, picking up ip addresses from a file
# Doing this time with 'textfsm' and functions.
# Let's plan and write the script.
# For this to work on windows please clone the ntc_templates folder 
# from "https://github.com/networktocode/ntc-templates.git" using --> "git clone <url>" command.
# in your C:\Users\username\ folder.
# Example TEXTFSM creation: http://jedelman.com/home/creating-templates-for-textfsm-and-ntc_show_command/

from netmiko import ConnectHandler
from getpass import getpass
from Netmiko_Script3 import get_auth_data, get_ipAddresses, create_session_details
from pprint import pprint


show_commands = ['dir', 'sh ip int br', 'sh vlan brief']

def main():
    user, pwd = get_auth_data()
    ipAddresses = get_ipAddresses('switchIPFile.txt')
    for ip in ipAddresses:
        switch = create_session_details(ip, user, pwd)

        session = ConnectHandler(**switch)
        hostname = session.find_prompt().strip('#')
        print('\n' * 2 + '=' * 80 + '\n' + f'Connected to host: {hostname}' + '\n' + '=' * 80)
        for cmd in show_commands:
            output = session.send_command(cmd, use_textfsm=True)
            pprint(output)
            # print(type(output))

if __name__ == '__main__':
    main()