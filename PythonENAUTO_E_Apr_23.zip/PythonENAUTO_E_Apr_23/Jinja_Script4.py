# MODERATE: Taking Input/Variable Values from a csv file.

import jinja2
import csv

csv_file = r'vrf_params.csv'

with open(csv_file) as f:
    csv_read = csv.DictReader(f)
    for vrf_variables in csv_read:
        rt_values = vrf_variables['rt_values']
        rt_values = rt_values.split()
        vrf_variables['rt_values'] = rt_values
        vrf_variables['check_ipv6'] = bool(vrf_variables['check_ipv6'])

        print(vrf_variables)

        template_file = r'vrf_template4.j2'
        with open(template_file) as f:
            vrf_template = f.read()
        
        template = jinja2.Template(vrf_template)
        print(template.render(vrf_variables))


# local_intf,sub_id,remote_intf,bw_kbps,vlan_outer,vlan_inner,self_ip_slash_mask,neighbor_ip,neighbor_as,neighbor_name,rt_values,check_ipv6,self_ipv6_slash_mask
# xe-0/2/3,77,Ge-1/0/1.77,30000,1200,77,10.120.100.10/30,10.120.100.11,65000,CPE-RTR1,20001 20011 20021,True,2001:123:12A::10/112
# xe-0/2/4
# csv_read = [
#     {
#         'local_intf': xe-0/2/3,
#         'sub_id': 77,
#         'check_ipv6': 'True',
#     },
#     {
#         'local_intf': xe-0/2/4,
#     }
# ]