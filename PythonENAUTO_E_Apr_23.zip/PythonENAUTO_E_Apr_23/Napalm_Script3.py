from napalm import get_network_driver
import json


driver = get_network_driver('ios')
session = driver('2.2.2.2', 'python', 'python')

session.open()
bgp_neighbors = session.get_bgp_neighbors()
print(json.dumps(bgp_neighbors, indent=4, sort_keys=True))

arp_entries = session.get_arp_table()
print(json.dumps(arp_entries, indent=4, sort_keys=True))

ping = session.ping('192.168.25.1')
print(json.dumps(ping, indent=4, sort_keys=True))

session.close()

# HOMEWORK
#TABLE
# PEER-IP   STATUS   LOCAL_AS  REMOTE_AS   UPTIME   SENT_PREFIXES