# Simple Script to login to vManage 

import requests
import json
from rich.console import Console
from rich.table import Column, Table
import urllib3

urllib3.disable_warnings()
# BASE_URL = "https://sandbox-sdwan-1.cisco.com:443/"

BASE_URL = "https://172.16.4.41:443/"

def viptela_authenticate(BASE_URL, username, password):
    auth_url = f'{BASE_URL}j_security_check'
    payload = {'j_username' : username, 'j_password' : password}
    headers = {
      'Content-Type': 'application/x-www-form-urlencoded',
    }

    response = requests.post(auth_url, data=payload, verify=False)
    cookies = response.headers["Set-Cookie"]
    jsessionid = cookies.split(";")
    cookie = jsessionid[0]
    # print(cookie)

    if response.status_code == 200:
        return 'AUTH_DONE', cookie
    else:
        return 'AUTH_ERROR', response.status_code

def viptela_get_token(BASE_URL, cookies):
    token_url = f'{BASE_URL}dataservice/client/token'
    payload={}
    headers = {
        'Cookie': cookies
    }
    response = requests.get(token_url, headers=headers, data=payload, verify=False)
    if response.status_code == 200:
        return str(response.text)
    else:
        return 'TOKEN_RETRIEVAL_FAILURE'

def viptela_get_all_devices(BASE_URL, cookies, TOKEN):
    all_device_url = f'{BASE_URL}dataservice/device?deviceId=10.9.9.202'  # deviceId=10.9.9.202
    payload = {}
    headers = {
        'Cookie': cookies,
        'X-XSRF-TOKEN': TOKEN
    }

    response = requests.get(all_device_url, headers=headers, data=payload, verify=False)
    print(response.text)
    response_json = json.loads(response.text)
    return response_json

def pretty_print_device_data(data):
    console = Console()
    table = Table(show_header=True, header_style='bold magenta')
    column_list = ['HOSTNAME', 'SYSTEM-IP', 'REACHABILITY', 'STATUS', 'DEVICE-TYPE',
                   'SITE-ID', 'OS-VERSION', 'OMP-PEERS', 'CONTROL-SESSIONS', 'BFD-SESSIONS-UP']
    for column in column_list:
        table.add_column(column)

    for device in data:
        if 'ompPeers' not in device:
            ompPeers = 'None'
        else:
            ompPeers = device['ompPeers']
        
        if 'controlConnections' not in device:
            controlConnections = 'None'
        else:
            controlConnections = device['controlConnections']

        if device['reachability'] == 'unreachable':
            reach = f'[red]unreachable[/red]'
        else:
            reach = f"[green]{device['reachability']}[/green]"

        if 'bfdSessionsUp' in device:
            bfd_sess = device['bfdSessionsUp']
        else:
            bfd_sess = 'None'
        
        table.add_row(device['host-name'], device['system-ip'], reach, device['status'], device['device-model'], 
                      device['site-id'], device['version'], ompPeers, controlConnections, str(bfd_sess))
    console.print(table)

def viptela_get_interface_stats_for_a_vedge(BASE_URL, sys_ip, cookies, TOKEN):
    interface_url = f'{BASE_URL}dataservice/device'
    payload = {}
    headers = {
        'Cookie': cookies,
        'X-XSRF-TOKEN': TOKEN
    }

    response = requests.get(interface_url, headers=headers, data=payload, verify=False)
    # print(type(response.text))
    response_json = json.loads(response.text)
    return response_json

def main():
    username = 'admin'
    password = 'Elastic+123'


    # CODE PORTION TO AUTHENTICATE WITH VMANAGE
    print('[AUTHENTICATING] This might take a moment...')
    auth_status, cookie_or_code = viptela_authenticate(BASE_URL, username, password)
    if 'DONE' in auth_status:
        print(f'[AUTHENTICATION STATUS] SUCCESS {auth_status.lower()} {cookie_or_code}')
    else:
        print(f'[AUTHENTICATION STATUS] FAILURE {auth_status} {cookie_or_code}')
    

    # CODE PORTION TO RETRIEVE TOKEN USED IN SUBSEQUENT REQUESTS
    print('[TOKEN RETRIEVAL] This might take a moment...')
    token = viptela_get_token(BASE_URL, cookie_or_code)
    print(f'[TOKEN RETRIEVAL] TOKEN: {token}')

    print('[DEVICE-DATA RETRIVAL] This might take a moment...')


    # CODE PORTION TO RETRIEVE TOKEN USED IN SUBSEQUENT REQUESTS
    response_dict1 = viptela_get_all_devices(BASE_URL, cookie_or_code, token)
    print(json.dumps(response_dict1['data'], indent=4))
    pretty_print_device_data(response_dict1['data'])


    # CODE PORTION TO RETRIEVE INTERFACE-STATS FOR A PARTICULAR VEDGE
    # response_dict2 = viptela_get_interface_stats_for_a_vedge(BASE_URL, '198.19.44.93', cookie_or_code, token)
    # print(json.dumps(response_dict2['data'], indent=4))



if __name__ == '__main__':
    main()