# Step 1: Import the required libraries.
import telnetlib
from getpass import getpass

# Step 2: Get user/pwd info from the user.
#         Also define the HOST(IP) with which telnet session has to be created.
user = input('Enter your Telnet Username: ')
password = getpass()

# Step 3: Open and read the file with ip addresses in it

with open('switchIPFile.txt') as f:
    ipAddrList = f.read().splitlines()

for ip in ipAddrList:
    session = telnetlib.Telnet(ip)
    # Step 4: Handle the username/password(AUTHENTICATION) prompt that the device gives.
    session.read_until(b'Username: ')
    session.write(user.encode('ascii') + b'\n')
    session.read_until(b'Password: ')
    session.write(password.encode('utf-8') + b'\n')

    session.write(b'ter len 0\n')
    session.write(b'sh running-config\n')
    session.write(b'exit\n')

    output = session.read_all().decode()

    with open(f'Switch_{ip}.txt', 'w') as f:
        f.write(output)
        f.write('\n')
    
    print(output)