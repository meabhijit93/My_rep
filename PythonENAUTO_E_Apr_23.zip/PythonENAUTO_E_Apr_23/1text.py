# print(5 + 5)

# print(5 - 5)

# print("Hello World!")

weight = 72    # in Kgs
height1 = 1.92  # in Mtrs
height2 = 1.82
height3 = 1.42
height4 = 1.67

bmi = weight / (height1 ** 2)
print(bmi)