from ncclient import manager
import xml.etree.ElementTree as ET

host = "192.168.25.23"  # Device IP/FQDN in here
port = "830"            # Netconf port number 830 or respective mapped port no. if PAT is being used
username = "python"  # SSH Credentials
password = "python"


with manager.connect(host=host, port=port, username=username, password=password, hostkey_verify=False) as m:

    yang_model_schema = m.get_schema('ietf-ipv4-unicast-routing')

    root = ET.fromstring(yang_model_schema.xml)

    yang_tree = list(root)[0].text

    f = open('ietf-ipv4-unicast-routing.yang', 'w')

    f.write(yang_tree)

    f.close()

# ietf-interfaces.yang
# ietf-inet-types.yang
# ietf-yang-types.yang
# ietf-ip.yang
# ietf-routing.yang
# ietf-ipv4-unicast-routing.yang