from ncclient import manager
import xmltodict

conn_params = {
    'host': "192.168.25.23",
    'port': "830",
    'username': "python",
    'password': "python",
    'hostkey_verify': False,
}

with manager.connect(**conn_params) as m:
    netconf_reply = m.get(filter=('xpath', "/interfaces-state/interface[name='GigabitEthernet2']"))
    interface_dict = xmltodict.parse(netconf_reply.xml)
    intf_data = interface_dict['rpc-reply']['data']
    intf_oper = intf_data['interfaces-state']['interface']

    print('\n')
    print('Interfaces details are as follows: ')
    print('Name: {}'.format(intf_oper['name']))
    print('  Packets Input: {}'.format(intf_oper['statistics']['in-unicast-pkts']))
    print('  Packets Output: {}'.format(intf_oper['statistics']['out-unicast-pkts']))