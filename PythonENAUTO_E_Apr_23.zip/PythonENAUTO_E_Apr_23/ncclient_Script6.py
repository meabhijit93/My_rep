from ncclient import manager, xml_


conn_params = {
    'host': "192.168.25.23",
    'port': "830",
    'username': "python",
    'password': "python",
    'hostkey_verify': False,
}

with manager.connect(**conn_params) as m:
    save_body = '<cisco-ia:save-config xmlns:cisco-ia="http://cisco.com/yang/cisco-ia"/>'
    save_rpc = m.dispatch(xml_.to_ele(save_body))
    print(save_rpc)