import requests
import sys
import json

requests.packages.urllib3.disable_warnings()

# HOST = 'ios-xe-mgmt-latest.cisco.com'
# PORT = 9443
# USER = 'developer'
# PASS = 'C1sco12345'

HOST = '192.168.25.23'
PORT = 443
USER = 'amit'
PASS = 'cisco'


def get_configured_interfaces():
    url = "https://{h}:{p}/restconf/data/ietf-interfaces:interfaces".format(h=HOST, p=PORT)
    # RESTCONF media types for REST API headers
    headers = {'Content-Type': 'application/yang-data+json',
               'Accept': 'application/yang-data+json'}
    # this statement performs a GET on the specified url
    response = requests.get(url, auth=(USER, PASS),
                            headers=headers, verify=False)

    # return the json as text
    print(response.status_code)
    return response.text


def main():
    interfaces = get_configured_interfaces()

    # print(interfaces)
    parsed_json = (json.loads(interfaces))
    # for detail, value in parsed_json["ietf-interfaces:interfaces"]["interface"][0].items():
    #     print(str(detail) + ' -> ' + str(value))
    for record in parsed_json["ietf-interfaces:interfaces"]["interface"]:
        print("{0:<35}".format("interface:  " + record["name"]), end="")
        if('address' in record["ietf-ip:ipv4"]):
            print ("{0:<15}".format(record["ietf-ip:ipv4"]["address"][0]["ip"]), end="")
            print("{0:<16}".format(record["ietf-ip:ipv4"]["address"][0]["netmask"]), end="")
        else:
            print ("{0:<15}".format("No IPv4"), end="")
            print ("{0:<16}".format("No MASK"), end="")
        print("{0:<9}".format("status:  "), end="")
        print(str(record["enabled"]))



if __name__ == '__main__':
    sys.exit(main())