from netmiko import ConnectHandler
from getpass import getpass

# user = input('SSH Username: ')
# pwd = getpass()


# user = 'python'
# pwd = 'python'
show_commands = ['dir', 'sh ip int br', 'sh ip bgp summary', 'sh ip protocol summary']

def get_auth_data():
    user = input('Enter your Username: ')
    password = getpass()
    return user, password

def get_ipAddresses(filename):
    with open(filename, 'r') as f:
        ipAddrList = f.read().splitlines()
    return ipAddrList

def create_session_details(ip, user, pwd):
    return {
        'device_type': 'cisco_ios',
        'host': ip,
        'username': user,
        'password': pwd,
    }

def send_show_cmd_or_cmds(session, commands):
    if type(commands) == str:
        output = session.send_command(commands)
        return output
    else:
        output = '\n'
        for cmd in commands:
            output += '\n' + session.send_command(cmd)
        return output


def main():
    ip_addresses = get_ipAddresses('switchIPFile.txt')
    user, pwd = get_auth_data()
    for ip in ip_addresses:
        switch = create_session_details(ip, user, pwd)
        session = ConnectHandler(**switch)
        hostname = session.find_prompt().strip('#')
        print('\n' * 2 + '=' * 80 + '\n' + f'Connected to host: {hostname}' + '\n' + '=' * 80)
        output = send_show_cmd_or_cmds(session, show_commands)
        print(output)


if __name__ == '__main__':
    main()