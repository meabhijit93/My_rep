# ADVANCE: Taking Input/Variable Values from a YAML file 
#          and handling nested loops in Jinja File.

import yaml
import jinja2
from pprint import PrettyPrinter

YAML_FILE_PATH = r'Jinja_test_yaml2.yml'

def read_yaml(path=YAML_FILE_PATH):
    with open(path) as file:
        yaml_content = yaml.safe_load(file.read())
    return yaml_content


yaml_dict = read_yaml()
pp = PrettyPrinter(indent=2)
pp.pprint(yaml_dict)

template_file = r'vrf_template5.j2'
with open(template_file) as f:
    vrf_template = f.read()

template = jinja2.Template(vrf_template, keep_trailing_newline=True)
print()
print('='*90)
print(template.render(yaml_dict))
print('='*90)
print()