import yaml
from pprint import pprint

yaml_file = r'G:\My Drive\PYTHON\Scripts\PythonENAUTO_E_Apr_23\Yaml_file_7.yml'

with open(yaml_file) as f:
    output = yaml.safe_load(f)

pprint(output)
print(type(output))

print(output['rtr1'])