from netmiko import ConnectHandler
from getpass import getpass

user = input('SSH Username: ')
pwd = getpass()

R1 = {
    'device_type': 'cisco_ios',
    'host': '1.1.1.1',
    'username': user,
    'password': pwd,
}


session = ConnectHandler(**R1)
# session = ConnectHandler(device_type='cisco_ios', host='1.1.1.1', username=user, password=pwd)

output = session.send_command('dir', strip_prompt=False, strip_command=False)
print(output)

output = session.send_command('sh ip int brief')
print(output)

output = session.send_command('sh ip bgp summary')
print(output)

output = session.send_command('sh ip protocol summary', strip_prompt=False, strip_command=False)
print(output)