from netmiko import ConnectHandler
from getpass import getpass

user = input('SSH Username: ')
pwd = getpass()

SW1 = {
    'device_type': 'cisco_ios',
    'host': '192.168.25.11',
    'username': user,
    'password': pwd,
}

SW2 = {
    'device_type': 'cisco_ios',
    'host': '192.168.25.12',
    'username': user,
    'password': pwd,
}

SW3 = {
    'device_type': 'cisco_ios',
    'host': '192.168.25.13',
    'username': user,
    'password': pwd,
}

SW4 = {
    'device_type': 'cisco_ios',
    'host': '192.168.26.14',
    'username': user,
    'password': pwd,
}

SW5 = {
    'device_type': 'cisco_ios',
    'host': '192.168.26.15',
    'username': user,
    'password': pwd,
}

switches = [SW1, SW2, SW3, SW4, SW5]

for switch in switches:
    session = ConnectHandler(**switch)
    hostname = session.find_prompt().strip('#')
    print('\n' * 2 + '=' * 80 + '\n' + f'Connected to host: {hostname}' + '\n' + '=' * 80)
    # for n in range(2, 11):
    #     output = session.send_config_set([f'vlan {n}', f'name NEW_VLAN_{n}'])
    #     print(output)

    config_commands = []
    for n in range(2, 11):
        config_commands.append(f'vlan {n}')
        config_commands.append(f'name NEW_VLAN_{n}')

    output = session.send_config_set(config_commands)
    print(output)
