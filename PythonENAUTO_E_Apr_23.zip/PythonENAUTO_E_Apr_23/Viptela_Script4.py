# SCRIPT TO TAKE PRE-POST LOGS

import requests
import json
from rich.console import Console
from rich.table import Column, Table
from rich.progress import Progress
import urllib3
import time


t1 = time.time()

urllib3.disable_warnings()
# BASE_URL = "https://sandbox-sdwan-1.cisco.com:443/"

BASE_URL = "https://172.16.4.41:443/"

dummy_file = r'dummy.txt'

def green(string):
    return f'[green]{string}[/green]'

def red(string):
    return f'[red]{string}[/red]'

def yellow(string):
    return f'[yellow]{string}[/yellow]'

def cyan(string):
    return f'[cyan]{string}[/cyan]'

def viptela_authenticate(BASE_URL, username, password):
    auth_url = f'{BASE_URL}j_security_check'
    payload = {'j_username' : username, 'j_password' : password}
    headers = {
      'Content-Type': 'application/x-www-form-urlencoded',
    }

    response = requests.post(auth_url, data=payload, verify=False)
    cookies = response.headers["Set-Cookie"]
    jsessionid = cookies.split(";")
    cookie = jsessionid[0]
    # print(cookie)

    if response.status_code == 200:
        return 'AUTH_DONE', cookie
    else:
        return 'AUTH_ERROR', response.status_code

def viptela_get_token(BASE_URL, cookies):
    token_url = f'{BASE_URL}dataservice/client/token'
    payload={}
    headers = {
        'Cookie': cookies
    }
    response = requests.get(token_url, headers=headers, data=payload, verify=False)
    if response.status_code == 200:
        return str(response.text)
    else:
        return 'TOKEN_RETRIEVAL_FAILURE'

def get_basic_device_details(BASE_URL, cookies, TOKEN, sys_ip, f):
    all_device_url = f'{BASE_URL}dataservice/device?deviceId={sys_ip}'
    payload = {}
    headers = {
        'Cookie': cookies,
        'X-XSRF-TOKEN': TOKEN
    }

    response = requests.get(all_device_url, headers=headers, data=payload, verify=False)
    response_dict = json.loads(response.text)
    column_list = ['HOST-NAME', 'LOCAL-SYS-IP', 'REACHABILITY', 'STATUS', 'DEVICE-GROUPS', 'DEVICE-TYPE','SITE-ID', 
                   'OS-VERSION','OMP-PEERS', 'CONTROL-SESSIONS', 'BFD-SESSIONS-UP', 'LAT', 'LONG']
    row_list = list()
    for elem in response_dict['data']:
        ompPeers = elem['ompPeers'] if 'ompPeers' in elem else '-'
        controlConnections = elem['controlConnections'] if 'controlConnections' in elem else '-'
        reach = red(elem['reachability']) if elem['reachability'] == 'unreachable' else elem['reachability']
        bfd_sess = elem['bfdSessionsUp'] if 'bfdSessionsUp' in elem else '-'
        lat = elem['latitude'] if 'latitude' in elem else '-'
        longitude = elem['longitude'] if 'longitude' in elem else '-'

        row_list.append([elem['host-name'], elem['system-ip'], reach, elem['status'], elem['device-groups'], elem['device-model'], 
                         yellow(elem['site-id']), elem['version'], ompPeers, controlConnections, bfd_sess, lat, longitude])
    row_list.append([yellow('TOTAL'), cyan(len(response_dict['data']))])
    pretty_print_device_data(column_list, row_list, 'DEVICE BASIC DETAILS', f)
    return response_dict

def get_template_details(BASE_URL, cookies, TOKEN, sys_ip, f):
    template_url = f'{BASE_URL}dataservice/system/device/vedges?deviceIP={sys_ip}'
    payload = {}
    headers = {
        'Cookie': cookies,
        'X-XSRF-TOKEN': TOKEN
    }

    response = requests.get(template_url, headers=headers, data=payload, verify=False)
    response_dict = json.loads(response.text)
    column_list1 = ['HOST-NAME', 'LOCAL-SYS-IP', 'DEVICE-MODEL', 'CONF-STATUS', 'SITE-ID', 
                   'DEV-STATE', 'REACHABILITY', 'OS-VERSION','DEFAULT-VERSION', 'AVAILABLE-VERs', 'VBOND']
    column_list2 = ['HOST-NAME', 'LOCAL-SYS-IP','OPER-MODE', 'SERIAL-NO.']
    column_list3 = ['TEMPLATE-LOG[s]', 'TEMPLATE']
    row_list1 = list()
    row_list2 = list()
    row_list3 = list()
    for elem in response_dict['data']:
        template = elem['template'] if 'template' in elem else '-'
        row_list1.append([elem['host-name'], elem['system-ip'], elem['deviceModel'], elem['configStatusMessage'], elem['site-id'], 
                        elem['deviceState'], elem['reachability'], elem['version'], elem['defaultVersion'], elem['availableVersions'], elem['vbond']])
        row_list2.append([elem['host-name'], elem['system-ip'], yellow(elem['configOperationMode']), elem['serialNumber']])
    
        row_list3.append([elem['templateApplyLog'], template])
    row_list1.append([yellow('TOTAL'), cyan(len(response_dict['data']))])
    row_list2.append([yellow('TOTAL'), cyan(len(response_dict['data']))])
    pretty_print_device_data(column_list1, row_list1, 'DEVICE AND TEMPLATE DATA', f)
    pretty_print_device_data(column_list2, row_list2, filename=f)
    pretty_print_device_data(column_list3, row_list3, filename=f)
    return response_dict

def get_control_conn_details(BASE_URL, cookies, TOKEN, sys_ip, f):                                     #['' , '', '', '', '', '', '', '', '', '', '','', '']
    control_url = f'{BASE_URL}dataservice/device/control/connections?deviceId={sys_ip}'
    payload = {}
    headers = {
        'Cookie': cookies,
        'X-XSRF-TOKEN': TOKEN
    }

    response = requests.get(control_url, headers=headers, data=payload, verify=False)
    response_dict = json.loads(response.text)
    column_list = ['HOST-NAME', 'LOCAL-SYS-IP', 'REMOTE-SYS-IP', 'LOCAL-COLOR','REMOTE-COLOR', 'UP-TIME', 
                   'STATE', 'PEER-TYPE', 'PRIVATE-IP','PRIVATE-PORT', 'PUBLIC-IP', 'PUBLIC-PORT', 'PROTOCOL']
    row_list = list()
    for elem in response_dict['data']:
        if elem['state'] != 'up':
            state = red(elem['state'])
        else:
            state = green(elem['state'])
        row_list.append([elem['vdevice-host-name'], elem['vdevice-name'], elem['system-ip'], elem['local-color'], elem['remote-color'], elem['uptime'], 
                        state, elem['peer-type'], elem['private-ip'],elem['private-port'], elem['public-ip'], elem['public-port'], elem['protocol']])
    row_list.append([yellow('TOTAL'), cyan(len(response_dict['data']))])
    pretty_print_device_data(column_list, row_list, 'SHOW CONTROL CONNECTIONS', f)
    return response_dict

def get_control_prop_details(BASE_URL, cookies, TOKEN, sys_ip, f):
    vpn_url = f'{BASE_URL}dataservice/device/control/localproperties?deviceId={sys_ip}'
    payload = {}
    headers = {
        'Cookie': cookies,
        'X-XSRF-TOKEN': TOKEN
    }

    response = requests.get(vpn_url, headers=headers, data=payload, verify=False)
    response_dict = json.loads(response.text)
    column_list1 = ['HOST-NAME', 'LOCAL-SYS-IP','SITE-ID','BOARD-SERIAL-NO.', 'MAX-CONTROLLERS', 'DNS-NAME']
    column_list2 = ['ORG-NAME', 'ACTIVE-WAN-INTFs', 'UUID', 'CERT-STATUS', 'CERT-VALIDITY','PORT-HOPPED', 'TIME-SINCE-LAST-HOP']
    row_list1 = list()
    row_list2 = list()
    for elem in response_dict['data']:
        row_list1.append([elem['vdevice-host-name'], elem['vdevice-name'], elem['site-id'], elem['board-serial'], elem['max-controllers'], elem['dns-name']])
        row_list2.append([elem['organization-name'], elem['number-active-wan-interfaces'], elem['uuid'], elem['certificate-status'], 
                          elem['certificate-validity'], elem['port-hopped'], elem['time-since-port-hop']])
    row_list1.append([yellow('TOTAL'), cyan(len(response_dict['data']))])
    pretty_print_device_data(column_list1, row_list1, 'SHOW CONTROL PROPERTIES', f)
    pretty_print_device_data(column_list2, row_list2, filename=f)
    return response_dict

def get_device_interface_details(BASE_URL, cookies, TOKEN, sys_ip, f):
    int_url = f'{BASE_URL}dataservice/device/interface?deviceId={sys_ip}'
    payload = {}
    headers = {
        'Cookie': cookies,
        'X-XSRF-TOKEN': TOKEN
    }

    response = requests.get(int_url, headers=headers, data=payload, verify=False)
    response_dict = json.loads(response.text)
    column_list = ['VPN','IF-NAME','IP-ADDRESS', 'ADMIN', 'OPER', 'DUPLEX', 'MTU', 'AUTO-NEG', 'SPEED(mbps)', 
                   'UPTIME','RX-DROPS', 'TX-DROPS', 'DESCRIPTION']
    row_list = list()
    for elem in response_dict['data']:
        # if elem['af-type'] != 'ipv4':
        #     continue
        duplex = elem['duplex'] if 'duplex' in elem else '-'
        duplex = green(duplex) if duplex == 'full' else red(duplex)
        auto_neg = elem['auto-neg'] if 'auto-neg' in elem else '-'
        auto_neg = yellow(auto_neg) if auto_neg == 'false' else auto_neg
        speed = elem['speed-mbps'] if 'speed-mbps' in elem else '0'
        if elem['if-oper-status'] == 'Up' and int(speed) < 1000:
            if 'ystem' or  'oopback' in elem['ifname']:
                pass
            else:
                speed = red(speed)
        desc = elem['desc'] if 'desc' in elem else '-'
        uptime = elem['uptime'] if 'uptime' in elem else '-'
        ifname = elem['ifname'] if 'loopback' not in elem['ifname'] else elem['ifname'].replace('loopback', 'Lo')
        ip_address = elem['ip-address'] if 'ip-address' in elem else '-'

        row_list.append([elem['vpn-id'], ifname, ip_address, elem['if-admin-status'], elem['if-oper-status'], 
                        duplex, elem['mtu'], auto_neg, speed, uptime, elem['rx-drops'], elem['tx-drops'], desc])
    row_list.append([yellow('TOTAL'), cyan(len(response_dict['data']))])
    pretty_print_device_data(column_list, row_list, 'SHOW INTERFACES', f)

    return response_dict

def get_bfd_details(BASE_URL, cookies, TOKEN, sys_ip, f):
    int_url = f'{BASE_URL}dataservice/device/bfd/sessions?deviceId={sys_ip}'
    payload = {}
    headers = {
        'Cookie': cookies,
        'X-XSRF-TOKEN': TOKEN
    }

    response = requests.get(int_url, headers=headers, data=payload, verify=False)
    response_dict = json.loads(response.text)
    column_list = ['HOST-NAME', 'LOCAL-SYS-IP','REMOTE-SYS-IP','LOCAL-COLOR', 'REMOTE-COLOR','SRC-IP', 'SRC-PORT','DEST-IP', 'DEST-PORT', 'STATE', 'UPTIME']
    row_list = list()
    for elem in response_dict['data']:
        state = elem['state']
        state = green(state) if state == 'up' else red(state)
        row_list.append([elem['vdevice-host-name'], elem['vdevice-name'], elem['system-ip'], elem['local-color'], elem['color'], 
                         elem['src-ip'], elem['src-port'], elem['dst-ip'], elem['dst-port'], state, elem['uptime']])
    row_list.append([yellow('TOTAL'), cyan(len(response_dict['data']))])
    pretty_print_device_data(column_list, row_list, 'BFD DETAILS', f)
    return response_dict

def get_omp_peer_details(BASE_URL, cookies, TOKEN, sys_ip, f):
    omp_peers_url = f'{BASE_URL}dataservice/device/omp/peers?deviceId={sys_ip}'
    payload = {}
    headers = {
        'Cookie': cookies,
        'X-XSRF-TOKEN': TOKEN
    }

    response = requests.get(omp_peers_url, headers=headers, data=payload, verify=False)
    response_dict = json.loads(response.text)
    column_list = ['HOST-NAME', 'LOCAL-SYS-IP','VSMART-IP','VSMART-SITEID', 'STATE', 'UPTIME', 'LEGIT', 'REFRESH']
    row_list = list()
    for elem in response_dict['data']:
        state = elem['state']
        state = green(state) if state == 'up' else red(state)
        row_list.append([elem['vdevice-host-name'], elem['vdevice-name'], elem['peer'], elem['site-id'], state, 
                         elem['up-time'], elem['legit'], elem['refresh']])
    row_list.append([yellow('TOTAL'), cyan(len(response_dict['data']))])
    pretty_print_device_data(column_list, row_list, 'OMP PEER DETAILS', f)
    return response_dict

def get_device_static_routes(BASE_URL, cookies, TOKEN, sys_ip, f):
    routes_url = f'{BASE_URL}dataservice/device/ip/routetable?deviceId={sys_ip}'
    payload = {}
    headers = {
        'Cookie': cookies,
        'X-XSRF-TOKEN': TOKEN
    }

    response = requests.get(routes_url, headers=headers, data=payload, verify=False)
    response_dict = json.loads(response.text)
    column_list = ['HOST-NAME', 'LOCAL-SYS-IP','VPN', 'PREFIX', 'NEXT-HOP-IP', 'NEXT-HOP-INTF', 'PROTOCOL', 'R S STATUS']
    row_list = list()
    static_list = list()
    for route in response_dict['data']:
        if route['protocol'] == 'static' or route['protocol'] == 'connected':
            static_list.append(route)
        else:
            continue
    for elem in static_list:
        next_hop = elem['nexthop-addr'] if 'nexthop-addr' in elem else '-'
        next_hop = yellow(next_hop) if elem['prefix'] == '0.0.0.0/0' else next_hop
        row_list.append([elem['vdevice-host-name'], elem['vdevice-name'], elem['vpn-id'], elem['prefix'], next_hop, 
                         elem['nexthop-ifname'], elem['protocol'], elem['rstatus']])
    row_list.append([yellow('TOTAL ROUTES'), cyan(len(response_dict['data'])), '', yellow('(ALL PROTOCOLs)')])
    pretty_print_device_data(column_list, row_list, 'STATIC & CONNECTED ROUTES', f)
    return static_list

def get_hardware_status(BASE_URL, cookies, TOKEN, sys_ip, f):
    routes_url = f'{BASE_URL}dataservice/device/hardware/status/summary?deviceId={sys_ip}'
    payload = {}
    headers = {
        'Cookie': cookies,
        'X-XSRF-TOKEN': TOKEN
    }

    response = requests.get(routes_url, headers=headers, data=payload, verify=False)
    response_dict = json.loads(response.text)
    column_list = ['LOCAL-SYS-IP', 'HW-TYPE', 'STATUS']
    row_list = list()
    for elem in response_dict['data']:
        if elem['hw-class'] == 'Fans':
            row_list.append([sys_ip, 'Fans', elem['status']])
            for key in elem['details']:
                row_list.append([sys_ip,key,list(elem['details'][key].values())])
        elif elem['hw-class'] == 'PEM':
            row_list.append([sys_ip, 'PEM', elem['status']])
            for key in elem['details']:
                row_list.append([sys_ip,key,list(elem['details'][key].values())])
        else:
            row_list.append([sys_ip, elem['hw-class'], elem['status']])
    row_list.append([yellow('TOTAL HARDWARES'), cyan(len(response_dict['data']))])
    pretty_print_device_data(column_list, row_list, 'HARDWARE STATUS SUMMARY', f)
    return response_dict

def get_ping_stats(BASE_URL, cookies, TOKEN, sys_ip, f):
    pass

def pretty_print_device_data(column_list, row_list, cmd=None, filename=None):
    console = Console(record=True)
    table = Table(show_header=True, header_style='bold magenta')
    for column in column_list:
        table.add_column(column)

    for row in row_list:
        table.add_row(*[str(i) for i in row])
    if cmd:
        console.print('', style='bold white on blue', justify='center')
        console.print(cmd, style='bold white on blue', justify='center')
        console.print('', style='bold white on blue', justify='center')

    console.print(table)
    console.save_text(dummy_file)
    with open(dummy_file, 'r', encoding="utf-8") as dummy:
        # print(dummy.read())
        with open(filename, 'a', encoding='utf-8') as f:
            f.write(str(dummy.read()))
            f.write('\n')



def main():
    username = 'admin'
    password = 'Elastic+123'
    sys_ip = '10.9.9.202'
    output_file = r'SD_WAN_output_file.txt'
    f = open(output_file, 'w')
    f.write('\n')
    f.close()
    # f = open(output_file, 'a')

    # CODE PORTION TO AUTHENTICATE WITH VMANAGE
    print('[AUTHENTICATING] This might take a moment...')
    auth_status, cookie_or_code = viptela_authenticate(BASE_URL, username, password)
    if 'DONE' in auth_status:
        print(f'[AUTHENTICATION STATUS] SUCCESS {auth_status.lower()} {cookie_or_code}')
    else:
        print(f'[AUTHENTICATION STATUS] FAILURE {auth_status} {cookie_or_code}')
    

    # CODE PORTION TO RETRIEVE TOKEN USED IN SUBSEQUENT REQUESTS
    print('[TOKEN RETRIEVAL] This might take a moment...')
    token = viptela_get_token(BASE_URL, cookie_or_code)
    print(f'[TOKEN RETRIEVAL] TOKEN: {token}')

    print('[DEVICE-DATA RETRIVAL] This might take a while...   <Approx 1 Minute>')

    basic_data = get_basic_device_details(BASE_URL, cookie_or_code, token, sys_ip, output_file)
    # # print(json.dumps(basic_data['data'], indent=4))

    device_int_data = get_device_interface_details(BASE_URL, cookie_or_code, token, sys_ip, output_file)
    # # print(json.dumps(device_int_data['data'], indent=4))

    routes_data = get_device_static_routes(BASE_URL, cookie_or_code, token, sys_ip, output_file)
    # print(json.dumps(routes_data, indent=4))

    template_data = get_template_details(BASE_URL, cookie_or_code, token, sys_ip, output_file)
    # print(json.dumps(template_data['data'], indent=4))
    
    control_data = get_control_conn_details(BASE_URL, cookie_or_code, token, sys_ip, output_file)
    # print(json.dumps(control_data['data'], indent=4))

    control_prop_data = get_control_prop_details(BASE_URL, cookie_or_code, token, sys_ip, output_file)
    # print(json.dumps(control_prop_data['data'], indent=4))

    device_bfd_data = get_bfd_details(BASE_URL, cookie_or_code, token, sys_ip, output_file)
    # print(json.dumps(device_bfd_data['data'], indent=4))

    omp_peer_data = get_omp_peer_details(BASE_URL, cookie_or_code, token, sys_ip, output_file)
    # print(json.dumps(omp_peer_data['data'], indent=4))

    hardware_data = get_hardware_status(BASE_URL, cookie_or_code, token, sys_ip, output_file)
    # print(json.dumps(hardware_data, indent=4))





if __name__ == '__main__':
    main()
    e = time.time() - t1
    print('--- Complete Task Execution took %02d:%02d:%02d ---'%(e // 3600, (e % 3600 // 60), (e % 60 // 1)))

# https://stackoverflow.com/questions/3682748/converting-unix-timestamp-string-to-readable-date