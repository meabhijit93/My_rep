from ncclient import manager
import xmltodict

conn_params = {
    'host': "192.168.25.23",
    'port': "830",
    'username': "python",
    'password': "python",
    'hostkey_verify': False,
}

netconf_template = open('config-ietf-interfaces.xml').read()

with manager.connect(**conn_params) as m:
    netconf_payload = netconf_template.format(
            int_name='GigabitEthernet2',
            int_desc="Configured by NETCONF by Amit",
            ip_address="10.10.10.1",
            subnet_mask="255.255.255.0"
        )
    print(netconf_payload)

    netconf_reply = m.edit_config(netconf_payload, target='running')
    print(netconf_reply)