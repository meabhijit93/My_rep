from napalm import get_network_driver
import json


driver = get_network_driver('ios')
SW1 = driver('192.168.25.11', 'python', 'python')

SW1.open()

facts = SW1.get_facts()
print(type(facts))
print(json.dumps(facts, indent=4))

interfaces = SW1.get_interfaces()
print(type(interfaces))
print(json.dumps(interfaces, indent=4))

SW1.close()