# MODERATE: DECOUPLING TEMPLATE AND SCRIPTS + USING FOR LOOPS AND CONDIONALS

import jinja2

vrf_variables = {
    'local_intf': 'xe-0/2/3',
    'sub_id': '77',
    'remote_intf': 'Ge-1/0/1.77',
    'bw_kbps': '30000',
    'vlan_outer': 1200,
    'vlan_inner': 77,
    'self_ip_slash_mask': '10.120.100.10/30',
    'neighbor_ip': '10.120.100.11',
    'neighbor_as': 65000,
    'neighbor_name': 'CPE-RTR1',
    'rt_values': ['20001', '20011', '20021'],
    'check_ipv6': True,
    'self_ipv6_slash_mask': '2001:123:12A::10/112'
}

# Normal Template
# r'G:\My Drive\PYTHON\Scripts\PythonENAUTO_E_Apr_23\vrf_template1.j2'
# template_file = r'vrf_template1.j2'
# with open(template_file) as f:
#     vrf_template = f.read()

# Checking out For loops
# template_file = r'vrf_template2.j2'
# with open(template_file) as f:
#     vrf_template = f.read()

# Taking Care of extra-line spaces
# template_file = r'vrf_template3.j2'
# with open(template_file) as f:
#     vrf_template = f.read()


# Checking Out if/else conditions
template_file = r'vrf_template4.j2'
with open(template_file) as f:
    vrf_template = f.read()

template = jinja2.Template(vrf_template)
print(template.render(vrf_variables))