from ncclient import manager

host = '192.168.25.23'
port = '830'
username = 'python'
password = 'python'

session = manager.connect(host=host, port=port, username=username, password=password, hostkey_verify=False)

print('=' * 90 + '\n' + 'The NETCONF capabilities of this router are: ' + '\n' + '=' * 90 + '\n')

for capability in session.server_capabilities:
    print(capability)

session.close_session()