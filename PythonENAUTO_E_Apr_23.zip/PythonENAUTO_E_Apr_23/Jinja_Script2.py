# BASIC: Creating new Variables, Using Formulas and Filters within the template.


import jinja2

vrf_variables = {
    'local_intf': 'xe-0/2/3',
    'sub_id': '77',
    'remote_intf': 'Ge-1/0/1.77',
    'bw_kbps': '30000',
    'vlan_outer': 1200,
    'vlan_inner': 77,
    'self_ip_slash_mask': '10.120.100.10/30',
    'neighbor_ip': '10.120.100.11',
    'neighbor_as': 65000,
    'neighbor_name': 'CPE-RTR1',
}


vrf_template = """

{% set bw_mbps = (bw_kbps | int / 1000) | int %}

set interfaces {{ local_intf }} unit {{ sub_id }} description " CUSTOMER-VRF-1 - to {{ neighbor_name}} - {{ remote_intf }} - {{ bw_mbps }}M"
set interfaces {{ local_intf }} unit {{ sub_id }} bandwidth {{ bw_mbps }}m
set interfaces {{ local_intf }} unit {{ sub_id }} vlan-tags outer {{ vlan_outer }}
set interfaces {{ local_intf }} unit {{ sub_id }} vlan-tags inner {{ vlan_inner }}
set interfaces {{ local_intf }} unit {{ sub_id }} family inet mtu 1500
set interfaces {{ local_intf }} unit {{ sub_id }} family inet no-redirects
set interfaces {{ local_intf }} unit {{ sub_id }} family inet filter input FILTER-COMMON-IN
set interfaces {{ local_intf }} unit {{ sub_id }} family inet address {{ self_ip_slash_mask }}

set class-of-service interfaces {{ local_intf }} unit {{ sub_id }} output-traffic-control-profile TRAFFIC-CTRL-SILVER-{{ bw_mbps }}M-L1-OUT
set class-of-service interfaces {{ local_intf }} unit {{ sub_id }} classifiers dscp DSCP-SILVER-IN

set policy-options community CUSTOMER-VRF-1-RTs members target:3540:20001
set policy-options community CUSTOMER-VRF-1-RTs members target:3540:20011
set policy-options community CUSTOMER-VRF-1-RTs members target:3540:20021

set policy-options policy-statement CUSTOMER-VRF-1-POLICY-IN term ACCEPT from community CUSTOMER-VRF-1-RTs
set policy-options policy-statement CUSTOMER-VRF-1-POLICY-IN term ACCEPT then accept
set policy-options policy-statement CUSTOMER-VRF-1-POLICY-IN term NEXT-POLICY then next policy

set policy-options policy-statement CUSTOMER-VRF-1-POLICY-OUT term ACCEPT from community add CUSTOMER-VRF-1-RTs
set policy-options policy-statement CUSTOMER-VRF-1-POLICY-OUT term ACCEPT then accept
set policy-options policy-statement CUSTOMER-VRF-1-POLICY-OUT term NEXT-POLICY then next policy

set routing-instances CUSTOMER-VRF-1 interface {{ local_intf }}.{{ sub_id }}

set routing-instances CUSTOMER-VRF-1 protocols bgp group CPE neighbor {{ neighbor_ip }} description "TO {{ neighbor_name }}"
set routing-instances CUSTOMER-VRF-1 protocols bgp group CPE neighbor {{ neighbor_ip }} import IMPORT-COMMON-IN1
set routing-instances CUSTOMER-VRF-1 protocols bgp group CPE neighbor {{ neighbor_ip }} import IMPORT-COMMON-IN2
set routing-instances CUSTOMER-VRF-1 protocols bgp group CPE neighbor {{ neighbor_ip }} export EXPORT-COMMON-OUT1
set routing-instances CUSTOMER-VRF-1 protocols bgp group CPE neighbor {{ neighbor_ip }} export EXPORT-COMMON-OUT2
set routing-instances CUSTOMER-VRF-1 protocols bgp group CPE neighbor {{ neighbor_ip }} peer-as {{ neighbor_as }}
"""

template = jinja2.Template(vrf_template)
print(template.render(vrf_variables))