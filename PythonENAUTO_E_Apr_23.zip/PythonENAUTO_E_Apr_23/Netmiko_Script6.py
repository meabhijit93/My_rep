from netmiko import ConnectHandler
from getpass import getpass
from Netmiko_Script3 import get_ipAddresses, get_auth_data, create_session_details
from pprint import pprint

def main():
    user, pwd = get_auth_data()
    ipAddresses = get_ipAddresses('switchIPFile.txt')
    for ip in ipAddresses:
        switch = create_session_details(ip, user, pwd)

        session = ConnectHandler(**switch)
        hostname = session.find_prompt().strip('#')
        print('\n' * 2 + '=' * 80 + '\n' + f'Connected to host: {hostname}' + '\n' + '=' * 80)

        output = session.send_command('dir', use_textfsm=True)
        for element in output:
            # print('Filename: {}         Size: {}        Last Modified: {}'.format(
            #                                                                     element['name'],
            #                                                                     element['size'],
            #                                                                     element['date_time']
            #                                                                     ))
            print(f'Filename: {element["name"].ljust(27)} Size: {element["size"].ljust(10)} Last Modified: {element["date_time"]}')
        print('-' * 60)

        output = session.send_command('show ip int br', use_textfsm=True)
        # Printing out output for only the interfaces which have ip addresses assigned to them.
        for element in output:
            if not element['ipaddr'] == 'unassigned':
                print('Interface: {}       IP-Address: {}        Enabled: {}       Status: {}'.format(
                                                                                                    element['intf'],
                                                                                                    element['ipaddr'],
                                                                                                    element['proto'],
                                                                                                    element['status']
                                                                                                    ))
        print('-' * 60)
        
        output = session.send_command('show interfaces', use_textfsm=True)
        for element in output:
            print('Interface: {}        Duplex: {}        Input/Output Rate: {}/{}'.format(
                                                                                            element['interface'],
                                                                                            element['duplex'],
                                                                                            element['input_rate'],
                                                                                            element['output_rate']
                                                                                        ))
        print('-' * 60)
        
        output = session.send_command('sh ip ospf neighbor', use_textfsm=True)
        for element in output:
            print('Neighbor-ID: {}          Address: {}        Interface: {}       State: {}'.format(
                                                                                                    element['neighbor_id'],
                                                                                                    element['address'],
                                                                                                    element['interface'],
                                                                                                    element['state']
                                                                                                    ))
        print('-' * 60)
        

if __name__ == '__main__':
    main()