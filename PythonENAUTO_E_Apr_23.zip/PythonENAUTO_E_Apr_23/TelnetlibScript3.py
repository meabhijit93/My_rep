# 192.168.25.11
# 192.168.25.12
# 192.168.25.13

# Step 1: Import the required libraries.
import telnetlib
from getpass import getpass

# Step 2: Get user/pwd info from the user.
#         Also define the HOST(IP) with which telnet session has to be created.
user = input('Enter your Telnet Username: ')
password = getpass()

# HOST = '192.168.25.11'


# Step 3: Telnet into host using this info
#         Basically we need to create a telnet session object that can used later
#         to write commands into and read outputs from.
for n in range(11, 14):
    HOST = '192.168.25.' + str(n)

    session = telnetlib.Telnet(HOST)

    # Step 4: Handle the username/password(AUTHENTICATION) prompt that the device gives.
    session.read_until(b'Username: ')
    session.write(user.encode('ascii') + b'\n')
    session.read_until(b'Password: ')
    session.write(password.encode('utf-8') + b'\n')

    session.write(b'conf ter\n')

    #[2, 3, 4....]
    for n in range(2, 21):
        vlanNo = str(n)
        session.write(b'vlan ' + vlanNo.encode() + b'\n')
        session.write(b'name P_VLAN_' + vlanNo.encode() + b'\n')

    session.write(b'end\n')
    session.write(b'exit\n')

    print(session.read_all().decode())

