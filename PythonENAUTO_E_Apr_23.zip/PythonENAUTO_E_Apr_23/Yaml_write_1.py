import yaml


device_detail_dict = {
 'rtr1': {'device_type': 'cisco_ios',
          'host': '1.1.1.1',
          'neighbors': ['192.168.25.11', '192.168.25.12', '192.168.26.13'],
          'password': 'admin',
          'username': 'admin'},
 'rtr2': {'device_type': 'juniper_junos',
          'host': '2.2.2.2',
          'neighbors': ['192.168.24.11', '192.168.24.12', '192.168.25.13'],
          'password': 'admin',
          'username': 'admin'},
 'rtr3': {'host': '3.3.3.3'}}

outputFile = r'G:\My Drive\PYTHON\Scripts\PythonENAUTO_E_Apr_23\Yaml_output.yaml'


with open(outputFile, 'w') as f:
    yaml.dump(device_detail_dict, f, default_flow_style=False)