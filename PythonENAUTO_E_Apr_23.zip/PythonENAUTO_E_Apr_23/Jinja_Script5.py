# ADVANCE: Taking Input/Variable Values from a YAML file.

import yaml
import jinja2

YAML_FILE_PATH = r'Jinja_test_yaml1.yml'

def read_yaml(path=YAML_FILE_PATH):
    with open(path) as file:
        yaml_content = yaml.safe_load(file.read())
    return yaml_content


yaml_dict = read_yaml()

template_file = r'vrf_template4.j2'
with open(template_file) as f:
    vrf_template = f.read()

template = jinja2.Template(vrf_template)
print(template.render(yaml_dict))