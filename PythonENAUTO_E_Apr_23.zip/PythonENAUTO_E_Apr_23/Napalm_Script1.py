from napalm import get_network_driver

driver = get_network_driver('ios')
SW1 = driver('192.168.25.11', 'python', 'python')

SW1.open()

facts = SW1.get_facts()
print(type(facts))
print(facts)

interfaces = SW1.get_interfaces()
print(type(interfaces))
print(interfaces)

SW1.close()