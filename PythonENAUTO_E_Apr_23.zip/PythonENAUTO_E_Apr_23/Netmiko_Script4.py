from netmiko import ConnectHandler
from getpass import getpass
from Netmiko_Script3 import get_auth_data, get_ipAddresses, create_session_details, send_show_cmd_or_cmds
from netmiko.exceptions import NetmikoTimeoutException
from paramiko.ssh_exception import AuthenticationException
from netmiko.exceptions import NetmikoAuthenticationException
from paramiko.ssh_exception import SSHException


show_commands = ['dir', 'sh ip int br', 'sh ip bgp summary', 'sh ip protocol summary']

def main():
    ip_addresses = get_ipAddresses('switchIPFile.txt')
    user, pwd = get_auth_data()

    for ip in ip_addresses:
        switch = create_session_details(ip, user, pwd)
        try:
            session = ConnectHandler(**switch)
        except (NetmikoTimeoutException):
            print(f'\n\nTimeout occured for device: {ip}\n\n')
            continue
        except (AuthenticationException):
            print(f'\n\nAuthentication Issue Occured, Check user Config on device: {ip}\n\n')
            continue
        except (NetmikoAuthenticationException):
            print(f'\n\nAuthentication Issue Occured, Check user Config on device: {ip}\n\n')
            continue
        except (SSHException):
            print(f'\n\nSSH Exception Occured, Check SSH Config on device: {ip}\n\n')
            continue
        except EOFError:
            print(f'\n\nEOF Error occured while connecting to, Check SSH Config/Reachability on device: {ip}\n\n')
            continue
        except Exception:
            print(f'\n\nSome Exception Occured while connecting to: {ip}\n\n')
            continue


        hostname = session.find_prompt().strip('#')
        print('\n' * 2 + '=' * 80 + '\n' + f'Connected to host: {hostname}' + '\n' + '=' * 80)
        output = send_show_cmd_or_cmds(session, show_commands)
        print(output)


if __name__ == '__main__':
    main()